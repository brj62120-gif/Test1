package com.banglakey.ime

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

/**
 * BanglaKey: offline Bengali/English IME prototype.
 * Bengali text is inserted as Unicode; Android's Bengali font/shaping engine
 * renders vowel signs and virama-based conjuncts.
 */
class BanglaKeyboardService : InputMethodService() {
    private var english = false
    private var shifted = false
    private var symbols = false
    private var layoutIndex = 0
    private lateinit var root: LinearLayout

    // Four editable layouts inspired by the user's reference image.
    private val banglaLayouts = listOf(
        listOf(
            listOf("◌ং", "◌ঃ", "◌ঁ", "◌ি", "◌ী", "ক", "খ", "গ", "ঘ", "ঙ"),
            listOf("◌ু", "◌ূ", "◌ৃ", "◌ে", "◌ৈ", "চ", "ছ", "জ", "ঝ", "ঞ"),
            listOf("◌ো", "◌ৌ", "◌্", "◌়", "◌ৗ", "ট", "ঠ", "ড", "ঢ", "ণ"),
            listOf("ত", "থ", "দ", "ধ", "ন", "প", "ফ", "ব", "ভ", "ম"),
            listOf("য", "র", "ল", "শ", "ষ", "স", "হ", "ড়", "ঢ়", "য়")
        ),
        listOf(
            listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও"),
            listOf("ঔ", "ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ"),
            listOf("ঞ", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ"),
            listOf("ন", "প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ"),
            listOf("ষ", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ")
        ),
        listOf(
            listOf("অ", "আ", "ই", "ঈ", "উ", "ক", "খ", "গ", "ঘ", "ঙ"),
            listOf("চ", "ছ", "জ", "ঝ", "ঞ", "ট", "ঠ", "ড", "ঢ", "ণ"),
            listOf("ত", "থ", "দ", "ধ", "ন", "প", "ফ", "ব", "ভ", "ম"),
            listOf("য", "র", "ল", "শ", "ষ", "স", "হ", "ড়", "ঢ়", "য়"),
            listOf("ং", "ঃ", "ঁ", "া", "ি", "ী", "ু", "ূ", "ে", "ো")
        ),
        listOf(
            listOf("া", "ি", "ী", "ু", "ূ", "ৃ", "ে", "ৈ", "ো", "ৌ"),
            listOf("্", "়", "ৎ", "ং", "ঃ", "ঁ", "ক্ষ", "জ্ঞ", "ত্র", "শ্র"),
            listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
            listOf("ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"),
            listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ")
        )
    )

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(7))
            setBackgroundColor(Color.rgb(224, 224, 224))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        render()
    }

    private fun render() {
        if (!::root.isInitialized) return
        root.removeAllViews()

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val tools = listOf("⇄", "☺", "GIF", "▦", "▤", "⚙", "•••")
        tools.forEach { item ->
            val t = TextView(this).apply {
                text = item
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
                setPadding(dp(5), dp(7), dp(5), dp(7))
                contentDescription = when (item) {
                    "⇄" -> "Switch language"
                    "☺" -> "Emoji (not available in this prototype)"
                    "▦" -> "Symbols"
                    else -> item
                }
                if (item == "⇄") setOnClickListener {
                    english = !english
                    symbols = false
                    render()
                }
                if (item == "▦") setOnClickListener {
                    symbols = !symbols
                    render()
                }
            }
            toolbar.addView(t, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        root.addView(toolbar)

        val rows = when {
            symbols -> symbolRows()
            english -> englishRows()
            else -> banglaLayouts[layoutIndex]
        }
        rows.forEachIndexed { rowIndex, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val shown = if (english && shifted) key.uppercase() else key
                val view = makeKey(shown) { onKeyPressed(key) }
                line.addView(view, LinearLayout.LayoutParams(0, dp(47), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        addBottomKey(bottom, if (symbols) "ABC" else "!#1", 1f) {
            symbols = !symbols
            render()
        }
        addBottomKey(bottom, ",", .7f) { commit(",") }
        addBottomKey(bottom, if (english) "English" else "বাংলা", 3.8f) {
            commit(" ")
        }
        addBottomKey(bottom, "⌫", 1f) { deleteGrapheme() }
        addBottomKey(bottom, actionLabel(), 1f) { performEditorAction() }
        root.addView(bottom)
    }

    private fun addBottomKey(parent: LinearLayout, label: String, weight: Float, action: () -> Unit) {
        val key = makeKey(label, action)
        if (label == "বাংলা" || label == "English") {
            key.setOnLongClickListener {
                if (!english) layoutIndex = (layoutIndex + 1) % banglaLayouts.size
                render()
                true
            }
        }
        parent.addView(key, LinearLayout.LayoutParams(0, dp(48), weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        })
    }

    private fun englishRows(): List<List<String>> = listOf(
        "qwertyuiop".map { it.toString() },
        "asdfghjkl".map { it.toString() },
        listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫")
    )

    private fun symbolRows(): List<List<String>> = listOf(
        listOf("1","2","3","4","5","6","7","8","9","0"),
        listOf("@","#","$","%","&","-","+","(",")","/"),
        listOf("*","\"", "'",":",";","!","?","৳",".", "।")
    )

    private fun onKeyPressed(key: String) {
        when (key) {
            "⇧" -> { shifted = !shifted; render() }
            "⌫" -> deleteGrapheme()
            else -> {
                val value = when (key) {
                    "◌ং" -> "ং"; "◌ঃ" -> "ঃ"; "◌ঁ" -> "ঁ"
                    "◌ি" -> "ি"; "◌ী" -> "ী"; "◌ু" -> "ু"
                    "◌ূ" -> "ূ"; "◌ৃ" -> "ৃ"; "◌ে" -> "ে"
                    "◌ৈ" -> "ৈ"; "◌ো" -> "ো"; "◌ৌ" -> "ৌ"
                    "◌্" -> "্"; "◌়" -> "়"; "◌ৗ" -> "ৗ"
                    else -> if (english && shifted) key.uppercase() else key
                }
                commit(value)
                if (english && shifted) { shifted = false; render() }
            }
        }
    }

    private fun actionLabel(): String {
        return when (currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "⌕"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "↵"
        }
    }

    private fun performEditorAction() {
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun makeKey(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = if (label.length > 3) 14f else 20f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(35, 35, 35))
            typeface = Typeface.DEFAULT
            background = GradientDrawable().apply {
                setColor(Color.rgb(250, 250, 250))
                cornerRadius = dp(7).toFloat()
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    /**
     * Deletes one visible Bengali/Latin grapheme approximately: trailing
     * combining marks are removed with their base character. Virama-linked
     * conjuncts are removed one component at a time, as on many mobile IMEs.
     */
    private fun deleteGrapheme() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(16, 0)?.toString().orEmpty()
        if (before.isEmpty()) {
            ic.deleteSurroundingText(1, 0)
            return
        }
        var removeCount = 1
        var index = before.length
        var cp = before.codePointBefore(index)
        index -= Character.charCount(cp)
        removeCount += Character.charCount(cp) - 1

        while (index > 0 && isCombining(cp)) {
            cp = before.codePointBefore(index)
            index -= Character.charCount(cp)
            removeCount += Character.charCount(cp)
        }
        if (index > 0) {
            val previous = before.codePointBefore(index)
            if (previous == 0x09CD) { // Bengali virama: include virama and preceding base
                removeCount += Character.charCount(previous)
                index -= Character.charCount(previous)
                if (index > 0) {
                    val base = before.codePointBefore(index)
                    removeCount += Character.charCount(base)
                }
            }
        }
        ic.deleteSurroundingText(removeCount, 0)
    }

    private fun isCombining(codePoint: Int): Boolean {
        return Character.getType(codePoint) == Character.NON_SPACING_MARK.toInt() ||
            Character.getType(codePoint) == Character.COMBINING_SPACING_MARK.toInt() ||
            Character.getType(codePoint) == Character.ENCLOSING_MARK.toInt()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
