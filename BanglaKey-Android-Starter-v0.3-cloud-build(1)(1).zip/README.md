# BanglaKey — Android IME starter (v0.2)

A privacy-first, offline Bengali/English keyboard prototype for Android. The Bengali key-grid layouts are original approximations based on the user's supplied reference image; this project does not contain Samsung code or assets.

## Build the APK
1. Install Android Studio and its Android SDK Platform 35 + Build Tools.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to finish (Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 are declared in the project).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/`.

## Enable on the phone
1. Install the debug APK on the Realme C51.
2. Open **Settings → Additional settings → Keyboard & input method → Manage keyboards** (wording can vary).
3. Enable **BanglaKey Keyboard**.
4. Choose BanglaKey as the current/default keyboard.

## Prototype controls
- Tap `⇄` in the toolbar to switch Bengali/English.
- In Bengali mode, tap the center spacebar to insert a space.
- Long-press the center spacebar to cycle through four Bengali layouts.
- `!#1` opens a basic symbol/number page.
- Backspace removes a character; combining Bengali signs are grouped with their base where possible.
- The action key follows the focused text field (for example Search, Next, Done, or Enter).

## Current limitations
- This is a starter prototype, not a finished production keyboard or a Samsung Keyboard clone.
- Bengali layouts are approximations of the supplied screenshot and need user review for exact key order.
- The fourth layout includes common conjunct shortcuts (ক্ষ, জ্ঞ, ত্র, শ্র); full conjunct composition and predictive text are not implemented.
- Emoji, GIF, clipboard history, settings panel, number-row customization, swipe typing, and suggestion strip are not implemented yet.
- The toolbar icons other than language/symbol toggles are visual placeholders.
- The code has not been compiled with Android Gradle Plugin or tested on a physical Realme C51 in this environment. Build and test it before daily use.


## Build without a computer (using GitHub Actions)
This project includes `.github/workflows/android-apk.yml` for a cloud build. From an Android phone:
1. Create a GitHub account or sign in.
2. Create a new **public or private repository** named `BanglaKey`.
3. Upload the project files from this ZIP to the repository (extract the ZIP first; upload the contents, not the ZIP itself).
4. Open the repository's **Actions** tab and allow workflows if prompted.
5. Run **Build BanglaKey APK** using **Run workflow**, or wait for the first push build.
6. When the run finishes, open its summary and download the `BanglaKey-debug-apk` artifact. Extract it and install `app-debug.apk`.

This cloud workflow is provided as a route to build from a phone; it has not been executed or verified yet. GitHub may require repository/workflow permissions. The APK is a debug build and Android may ask you to allow installation from the browser/files app.
